# FlagPilot JavaScript SDK (MVP)

This package lets a JavaScript app evaluate flags against the FlagPilot API. It has a short in-memory cache and does not automatically emit analytics events; call `trackEvent` only when a feature is actually shown or a conversion action succeeds.

## Local installation

From the repository root, in a consuming app:

```bash
npm install ../sdk
```

If you publish this package later, install it with `npm install @flagpilot/client`.

## Usage

```js
import { FlagPilotClient } from "@flagpilot/client";

const flags = new FlagPilotClient({
  apiBaseUrl: "http://localhost:8000", // or a deployed API origin
  clientKey: "fp_dev_REPLACE_WITH_YOUR_DEVELOPMENT_CLIENT_KEY",
  environment: "dev",
  user: {
    id: "customer-123", // stable ID; don't use a new random ID on each request
    attributes: { role: "beta_tester", country: "IN" },
  },
});

const decision = await flags.evaluate("new_checkout");
if (decision.enabled) {
  // Render the new checkout in your own application.
  await flags.trackEvent({
    flagKey: "new_checkout",
    variant: decision.variant,
    event: "exposure",
  });
}


// Track a conversion only after the user's action succeeds:
await flags.trackEvent({
  flagKey: "new_checkout",
  variant: decision.variant,
  event: "conversion",
});
```

`evaluate` returns `enabled`, `value`, `variant`, and `reason`. If the API cannot be reached, the SDK returns a disabled `SDK_ERROR` decision and calls `onError` when supplied. Don't assume the fallback error decision is the same thing as a legitimate `FLAG_DISABLED` decision.

## Client key security

`clientKey` is a public project/environment-scoped key used only for flag evaluation and event ingestion. It is intentionally okay to include in browser apps, but it is not an authorization credential for management APIs. Treat user attributes sent from a browser (including role/plan claims) as untrusted input: feature flags are not an authorization boundary, and your own API must independently enforce access permissions. Management operations require a user JWT and are scoped to that user's project. Rotate a key from the SDK & API settings if it is abused; the old key is revoked immediately. Never place a JWT, database credential, or other server secret in browser code.

## Current limits

The SDK is an MVP client. Key management and project scoping are implemented, but the product still needs team invitations, external security review, production monitoring/backups, and deployed end-to-end testing before a production SaaS launch. Event counts are observational and are not causal experiment results.
