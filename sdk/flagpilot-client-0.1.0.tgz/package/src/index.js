const DEFAULT_API_URL = "http://localhost:8000/api/v1";
const DEFAULT_CACHE_TTL_MS = 5_000;
const ALLOWED_ENVIRONMENTS = new Set(["dev", "prod"]);

const normalizeApiUrl = (url) => {
  const trimmed = String(url || DEFAULT_API_URL).replace(/\/+$/, "");
  return trimmed.endsWith("/api/v1") ? trimmed : `${trimmed}/api/v1`;
};

const stableSerialize = (value) => {
  if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stableSerialize(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
};

/**
 * A small SDK client for browser and Node.js applications.
 *
 * The user ID should be stable for each end user so percentage rollout
 * assignment stays deterministic. `clientKey` is a public, project/environment-
 * scoped key limited to evaluation and event ingestion. Never put JWTs or
 * server secrets in browser bundles.
 */
export class FlagPilotClient {
  constructor({
    apiBaseUrl = DEFAULT_API_URL,
    clientKey,
    environment = "prod",
    user = {},
    cacheTtlMs = DEFAULT_CACHE_TTL_MS,
    timeoutMs = 2_000,
    fetchImpl = globalThis.fetch?.bind(globalThis),
    onError = () => {},
  } = {}) {
    if (!ALLOWED_ENVIRONMENTS.has(environment)) {
      throw new TypeError("environment must be 'dev' or 'prod'");
    }
    if (typeof fetchImpl !== "function") {
      throw new TypeError("Fetch is not available; provide fetchImpl or use Node.js 18+");
    }
    if (!Number.isFinite(cacheTtlMs) || cacheTtlMs < 0) {
      throw new TypeError("cacheTtlMs must be a non-negative number");
    }

    if (typeof clientKey !== "string" || !clientKey.trim()) {
      throw new TypeError("clientKey is required; copy the key for this environment from FlagPilot's SDK & API page");
    }
    this.apiBaseUrl = normalizeApiUrl(apiBaseUrl);
    this.clientKey = clientKey.trim();
    this.environment = environment;
    this.user = user || {};
    this.cacheTtlMs = cacheTtlMs;
    this.timeoutMs = timeoutMs;
    this.fetch = fetchImpl;
    this.onError = onError;
    this.cache = new Map();
  }

  setUser(user) {
    this.user = user || {};
    this.clearCache();
  }

  setEnvironment(environment) {
    if (!ALLOWED_ENVIRONMENTS.has(environment)) throw new TypeError("environment must be 'dev' or 'prod'");
    this.environment = environment;
    this.clearCache();
  }

  invalidate(key) {
    const normalized = String(key || "").trim().toLowerCase();
    const prefix = `${this.environment}:${normalized}:`;
    for (const cacheKey of this.cache.keys()) {
      if (cacheKey.startsWith(prefix)) this.cache.delete(cacheKey);
    }
  }

  clearCache() {
    this.cache.clear();
  }

  _cacheKey(key, attributes) {
    return [this.environment, key, this.user?.id || "anonymous", stableSerialize({
      ...(this.user?.attributes || {}), ...(attributes || {}),
    })].join(":");
  }

  async evaluate(key, { skipCache = false, attributes = {} } = {}) {
    const normalizedKey = String(key || "").trim().toLowerCase();
    if (!/^[a-z0-9][a-z0-9_.-]{0,99}$/.test(normalizedKey)) {
      throw new TypeError("key must start with a letter or number and contain only letters, numbers, dots, underscores, or hyphens");
    }

    const cacheKey = this._cacheKey(normalizedKey, attributes);
    const cached = this.cache.get(cacheKey);
    if (!skipCache && cached && cached.expiresAt > Date.now()) return cached.value;

    const controller = typeof AbortController === "function" ? new AbortController() : null;
    const timeout = controller && this.timeoutMs > 0 ? setTimeout(() => controller.abort(), this.timeoutMs) : null;

    try {
      const response = await this.fetch(`${this.apiBaseUrl}/feature-flags/evaluate`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-flagpilot-client-key": this.clientKey },
        signal: controller?.signal,
        body: JSON.stringify({
          key: normalizedKey,
          environment: this.environment,
          userId: String(this.user?.id || "anonymous"),
          attributes: { ...(this.user?.attributes || {}), ...(attributes || {}) },
        }),
      });
      if (!response.ok) {
        const payload = await response.json().catch(() => null);
        throw new Error(payload?.message || `Flag evaluation failed with HTTP ${response.status}`);
      }
      const payload = await response.json();
      const decision = payload?.data;
      if (!decision || typeof decision.enabled !== "boolean" || !Object.prototype.hasOwnProperty.call(decision, "value")) {
        throw new Error("The evaluation API returned an invalid response");
      }
      if (this.cacheTtlMs > 0) this.cache.set(cacheKey, { value: decision, expiresAt: Date.now() + this.cacheTtlMs });
      return decision;
    } catch (error) {
      this.onError(error, { operation: "evaluate", key: normalizedKey });
      return { enabled: false, value: false, variant: "control", reason: "SDK_ERROR" };
    } finally {
      if (timeout) clearTimeout(timeout);
    }
  }

  async getBooleanValue(key, fallback = false, options = {}) {
    const decision = await this.evaluate(key, options);
    if (decision.reason === "SDK_ERROR") return fallback;
    return typeof decision.value === "boolean" ? decision.value : fallback;
  }

  async getValue(key, fallback, options = {}) {
    const decision = await this.evaluate(key, options);
    return decision.reason === "SDK_ERROR" ? fallback : decision.value;
  }

  async trackEvent({ flagKey, event = "exposure", variant = "control", userId, metadata = {} } = {}) {
    const normalizedKey = String(flagKey || "").trim().toLowerCase();
    if (!normalizedKey) throw new TypeError("flagKey is required");
    if (!["exposure", "conversion"].includes(event)) throw new TypeError("event must be 'exposure' or 'conversion'");

    try {
      const response = await this.fetch(`${this.apiBaseUrl}/analytics/track`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-flagpilot-client-key": this.clientKey },
        body: JSON.stringify({
          userId: String(userId || this.user?.id || "anonymous"),
          flagKey: normalizedKey,
          environment: this.environment,
          variant,
          event,
          metadata,
        }),
      });
      if (!response.ok) {
        const payload = await response.json().catch(() => null);
        throw new Error(payload?.message || `Event tracking failed with HTTP ${response.status}`);
      }
      return response.json();
    } catch (error) {
      this.onError(error, { operation: "trackEvent", key: normalizedKey, event });
      throw error;
    }
  }
}

export default FlagPilotClient;
